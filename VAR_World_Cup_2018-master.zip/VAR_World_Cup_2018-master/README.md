# VAR World Cup 2018
Exploration of the effects that VAR had on the rate of penalties in the 2018 World Cup in Russian.
